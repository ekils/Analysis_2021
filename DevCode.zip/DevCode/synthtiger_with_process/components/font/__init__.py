"""
synthtiger_with_process
Copyright (c) 2021-present NAVER Corp.
MIT license
"""

from components.font.base_font import BaseFont

__all__ = ["BaseFont"]
