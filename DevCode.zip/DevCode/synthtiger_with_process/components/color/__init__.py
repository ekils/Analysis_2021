"""
synthtiger_with_process
Copyright (c) 2021-present NAVER Corp.
MIT license
"""

from components.color.color_map import ColorMap
from components.color.gray import Gray
from components.color.gray_map import GrayMap
from components.color.opacity import Opacity
from components.color.rgb import RGB
from components.color.rgb_map import RGBMap

__all__ = ["ColorMap", "Gray", "GrayMap", "Opacity", "RGB", "RGBMap"]
