"""
SynthTIGER
Copyright (c) 2021-present NAVER Corp.
MIT license
"""

from components.texture.base_texture import BaseTexture

__all__ = ["BaseTexture"]
