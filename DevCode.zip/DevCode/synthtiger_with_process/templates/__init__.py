"""
SynthTIGER
Copyright (c) 2021-present NAVER Corp.
MIT license
"""

from templates.template import Template

__all__ = ["Template"]
