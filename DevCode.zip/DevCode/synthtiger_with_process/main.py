"""
SynthTIGER
Copyright (c) 2021-present NAVER Corp.
MIT license
"""
import os
import argparse
import pprint
import time
import logging
import warnings

import gen as tiger

warnings.filterwarnings('ignore')
os.makedirs('./log', exist_ok=True)
logname = './log/log.txt'
logging.basicConfig(filename=logname,
                            filemode='a',
                            format='%(asctime)s,%(msecs)d %(name)s %(levelname)s %(message)s',
                            datefmt='%H:%M:%S',
                            level=logging.INFO)


def run(args):
    if args.config is not None:
        config = tiger.read_config(args.config)
    # pprint.pprint(config)
    logging.info(config)

    template = tiger.read_template(args.script, args.name, config)
    generator = tiger.generator(
        args.script, args.name, config, worker=args.worker, verbose=args.verbose
    )

    if args.output is not None:
        template.init_save(args.output, args.tov)

    for idx in range(args.count):
        data = next(generator)
        if args.output is not None:
            template.save(args.output, data, idx, args.tov)
        # print(f"Generated.... {idx + 1} data")
        logging.info("Generated.... {} data".format(idx + 1))

    if args.output is not None:
        template.end_save(args.output)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-o",
        "--output",
        metavar="DIR",
        type=str,
        help="Directory path to save data.",
    )
    parser.add_argument(
        "-c",
        "--count",
        metavar="NUM",
        type=int,
        default=100,
        help="Number of data. [default: 100]",
    )
    parser.add_argument(
        "-w",
        "--worker",
        metavar="NUM",
        type=int,
        default=0,
        help="Number of workers. If 0, It generates data in the main process. [default: 0]",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        default=False,
        help="Print error messages while generating data.",
    )
    parser.add_argument(
        "script",
        metavar="SCRIPT",
        type=str,
        help="Script file path.",
    )
    parser.add_argument(
        "name",
        metavar="NAME",
        type=str,
        help="Template class name.",
    )
    parser.add_argument(
        "config",
        metavar="CONFIG",
        type=str,
        nargs="?",
        help="Config file path.",
    )
    parser.add_argument(
        "tov",
        metavar="Train_or_Val",
        type=str,
        nargs="?",
        help="Config file path.",
    )
    args = parser.parse_args()

    # pprint.pprint(vars(args))
    logging.info(vars(args))
    return args


def main():
    start_time = time.time()
    args = parse_args()
    if os.path.isdir(args.output + '/' + args.tov):
        # print('Folder Has Already Built !!!!!\n')
        logging.info('Folder Has Already Built !!!!!\n')
        raise FileExistsError

    else:
        run(args)
        end_time = time.time()
        # print(f"{end_time - start_time:.2f} seconds elapsed")
        logging.info('{} seconds elapsed \n'.format(round(end_time - start_time),3))
        logging.info('==========    dataset :{}   created  Done   ============\n'.format(args.tov))     

main()
