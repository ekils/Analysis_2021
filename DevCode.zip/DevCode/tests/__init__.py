"""
SynthTIGER
Copyright (c) 2021-present NAVER Corp.
MIT license
"""
