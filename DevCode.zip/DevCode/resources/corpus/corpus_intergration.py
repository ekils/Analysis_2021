#!/usr/bin/python
# encoding:utf-8
import random
import re


#######################################################################################################################
# 去重複
ori_path = 'synthtext.txt'
final_path = 's.txt'

temp_list = []
with open(ori_path) as file:
    for line in file: 
        temp_list.append(line)
    file.close()

max_duplicate = 1

with open(final_path, 'w') as f:
    counter = 0
    green_light = True
    for item in temp_list:
        if green_light and counter <= max_duplicate:
            temp = item
            counter += 1
            f.write("%s" % item)

        elif (counter > max_duplicate) and (temp ==item):
            counter += 1
            green_light = False
        else:
            green_light = True
            counter =0




    f.close()



##################################################
# final_path = 'default_corpus/alphabet.txt'


# f = open(final_path, 'r')
# print(f.read())
# print(type(f.read()))
# f.close()

#######################################################################################################################
# # 產生 alphabet
# path1 = "mjsynth.txt"
# path2 = "synthtext.txt"
# path3 = "default_corpus/alphanum_special.txt"
# final_path = 'default_corpus/alphabet.txt'

# p1, p2, p3 = '','',''
# with open(path1, 'r') as outfile:
#     for fname in outfile:
#         p1 += fname


# with open(path2, 'r') as outfile:
#     for fname in outfile:
#         p2 += fname


# with open(path3, 'r') as outfile:
#     for fname in outfile:
#         p3 += fname

# p = p1+p2+p3

# final = list(set(p))
 
# print(final)
# print(len(final))

# final = [i for i in final if not i=='\n']
# print(len(final))
# final = ''.join(final)

# f = open(final_path, 'w')
# f.write(final)
# f.close()




#######################################################################################################################
# 合併corpus: 
# path1 ="default_corpus/chinese_3000_corpus_with_strip.txt"
# path2 = "default_corpus/diagnos_74210_corpus_with_strip.txt"
# final_path = 'mjsynth.txt'



# filenames = [path1, path2]
# with open(final_path, 'w') as outfile:
#     for fname in filenames:
#         with open(fname) as infile:
#             for line in infile:
#                 outfile.write(line)



#######################################################################################################################

# # 中文切斷落: 
# path ="default_corpus/chinese_3000_corpus.txt"
# final_path = 'mjsynth.txt'

# final_file = open(final_path, 'w')

# with open(path) as file:
#     for line in file: 
#         x = random.randint(3,10)
#         line = line.decode('utf8')
#         text = (re.sub(r"(.{})".format('{}'.format("{"+ str(x) + "}")), "\\1\n", line, 0, re.DOTALL)).encode('utf8')
#         if text[-1]=='\n':
#             text = text[:-1]
#         final_file.write(text)
#         # final_file.write('..\n')
#     final_file.close()



# # diagnosis corpus 斷詞: 
# path ="default_corpus/diagnos_74210_corpus.txt"
# final_path = 'temp.txt'
# final_file = open(final_path, 'w')

# with open(path) as file:
#     for line in file: 
#         x = random.randint(5,12)
#         line = line.decode('utf8')
#         text = (re.sub(r"(.{})".format('{}'.format("{"+ str(x) + "}")), "\\1\n", line, 0, re.DOTALL)).encode('utf8')
#         if text[-1]=='\n':
#             text = text[:-1]
#         final_file.write(text)
#     final_file.close()




#####################################################################################################################################
# synthtext 切斷落: 
# path ="synthtext_4953555.txt"
# final_path = 'synthtext.txt'

# final_file = open(final_path, 'w')

# with open(path) as file:
#     for line in file: 
#         x = random.randint(5,10)
#         if len(line) >= 15: 
#             text = (re.sub(r"(.{})".format('{}'.format("{"+ str(x) + "}")), "\\1\n", line, 0, re.DOTALL))
#             if text[-1]=='\n':
#                 text = text[:-1]
#             final_file.write(text)
#             final_file.write('..')
#         else:
#             final_file.write(line)
#     final_file.close()

