[先簡單紀錄]
1. 可以不需要安裝 synthtiger 套件
2  [如安裝] 
    2.1 外加參數無法新增 
    2.2 執行指令:   synthtiger -o results -c 1000 -w 4 -v examples/synthtiger/template.py SynthTiger examples/synthtiger/config_horizontal.yaml
3. [不安裝] 
    2.1 外加參數可以客製 
    2.2 執行指令:  synthtiger_with_process

4. [training data 背景執行:] sh generate.sh 100 train & 
5. [testing data 背景執行:] sh generate.sh 20 val & 
6. [刪除背景執行:]   killall -9 python3
7. [登出時能繼續使用] nohup sh generate.sh 100 train &  (掛最前面)