# -*- coding: utf-8 -*- 
import io
import argparse
import random

import lmdb 
from PIL import Image

"""
開啟mobaxterm ,連線上server
echo $DISPLAY (會回傳對應的連線ex: localhost:11.0)
open vscode, ,連線上server
開啟terminal : export DISPLAY=localhost:11.0
確認：echo $DISPLAY

再執行 python check_lmdb.py [任意正整數]
"""


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "choose",
        metavar="choose number",
        type=int,
        nargs="?",
        help="Config file path.",
    )
    args = parser.parse_args()
    return args



counter = 0
args = parse_args()
ran = random.randint(0, args.choose)

env_db = lmdb.Environment('results/train_lmdb') 
txn = env_db.begin() 

for key, value in txn.cursor(): 
    if counter == ran:
        print (key) 
        show_me = Image.open(io.BytesIO(value))
        show_me.show()
        break
    counter += 1
env_db.close()